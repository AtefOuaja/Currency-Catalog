import {ModuleWithProviders, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisplayerComponent } from './displayer/displayer.component';
import { OneCurrencyComponent } from './one-currency/one-currency.component';
import { CurrenciesService } from './currencies.service';
import {MatGridListModule , MatCardModule} from '@angular/material';
import {MatButtonModule} from '@angular/material';
import { FormsModule } from '@angular/forms';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatPaginatorModule} from '@angular/material/paginator';
import {RouterModule, Routes} from '@angular/router';
import {MatSortModule} from '@angular/material';
import {NgxPaginationModule} from 'ngx-pagination';
import { ActivatedRoute } from '@angular/router';


@NgModule({
  imports: [
    CommonModule,
    MatGridListModule,
    FormsModule,
    FlexLayoutModule,
    MatCardModule,
    MatAutocompleteModule,
    MatSelectModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    MatPaginatorModule,
    MatSortModule,
    NgxPaginationModule,
    RouterModule.forRoot([
      {path: 'OneCur/:id' , component : OneCurrencyComponent},
      {path: 'displayer' , component : DisplayerComponent}
      ])


  ],
  exports: [DisplayerComponent,
    MatGridListModule,
    FormsModule,
    FlexLayoutModule,
    MatCardModule,
    MatAutocompleteModule,
    MatSelectModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    MatPaginatorModule,
    NgxPaginationModule
      ],
  declarations: [DisplayerComponent, OneCurrencyComponent],
  providers: [CurrenciesService]
})
export class CurrenciesModule { }

