import {CurrencyAttribute} from './currencyAttribute';

export class Currency {
  id: number;
  attributes: CurrencyAttribute;
}
